/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package books;

import java.util.ArrayList;

/**
 *
 * @author arpandua
 */
public class Books {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    
    Books1 book1 = new Books1(1,"The sky",8);
    
    Books1 book2 = new Books1(2,"Necklace",9);
    
    Books1 book3 = new Books1(3,"Journey",7);
    
    Books1 book4 = new Books1(4,"Wonderer",8);
    
    ArrayList<Books1> library = new ArrayList<Books1>();
     library.add(book1);
     library.add(book2);
     library.add(book3);
     library.add(book4);
     System.out.println("no. of books " +library.size());
     
     for(Books1 bk: library)
     {
         
     }
    
    
    
    
    
    library.add(2,new Books1(10,"pacific",9));
}}








