/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package books;

/**
 *
 * @author arpandua
 */
public class Books1 {
    
int bookid;
String booktitle;
int bookrating;


Books1()
{
this.bookid = 0;
this.booktitle = "unknown";
this.bookrating = 0;
}

Books1(int bookid, String booktitle, int bookrating)
{
    this.bookid = bookid;
    this.booktitle = booktitle;
    this.bookrating = bookrating;
}
 void setid(int id)
 {
     this.bookid = id;
     
 }
  int getid()
  {
      return this.bookid;
    
  }

    public String getBooktitle() {
        return booktitle;
    }

    public int getBookrating() {
        return bookrating;
    }

    public void setBooktitle(String booktitle) {
        this.booktitle = booktitle;
    }

    public void setBookrating(int bookrating) {
        this.bookrating = bookrating;
    }

    
    
    void display()
    {
        System.out.println("Book ID :" +this.bookid);
    
        System.out.println("Book Title :" +this.booktitle);
    
        System.out.println("Book Rating :" +this.bookrating);
    
    }
  
  
}