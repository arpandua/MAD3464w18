/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tuesjava;

/**
 *
 * @author arpandua
 */
public class hello {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        float percentage;
        int num = 10;
        char vowel = 'a';
        ;
        System.out.println("value of num is " + num);
        percentage = 75.8f;
        System.out.println("value of percentage is " +percentage);
        System.out.println("value of vowel is " +vowel);
    
    
   int numbers[] = new int[5];
   int i;
   for(i=0;i<numbers.length;i++)
   {
       numbers[i] = (int) (Math.random()*100);
       System.out.println("numbers [" + i + "] = " +numbers[i]);
     
   }
    
    double PI_VALUE = Math.PI;
            double power = Math.pow(2,2);
                    Math.sqrt(144);
                    Math.abs(PI_VALUE);
    
    
                    float grades[] [] = new float [3] [4];
                    for(i=0; i <3;i++)
                    {
                        for(int j=0;j<4;j++)
                        {
                            grades[i][j] = 10.0f;
                        }
                    }
    }
}

