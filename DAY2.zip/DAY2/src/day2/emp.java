/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day2;

import java.util.Scanner;
/**
 *
 * @author arpandua
 *//**
 *
 * @author arpandua
 */
public class emp extends person {
 
    double salary;
    
    emp()
    {
        super();
        this.salary = 14;
    }
    
    emp(double pay)
    {
        this.salary = pay;
        
    }
    
    emp( String fname, String lname, int age, Double pay)
    {
        
        this.salary = pay;
        
    }
    
    void displayemp()
    {
        System.out.println("Salary " +this.salary);
    }
   
    
    void read(){
        
        Scanner  scanemp = new Scanner(System.in);
        this.salary = scanemp.nextDouble();

}
    emp(String fname, String lname, int age, double pay)
{
//super(fname, lname, age);
this.salary = pay;

}
    
    
    
    
    
}
