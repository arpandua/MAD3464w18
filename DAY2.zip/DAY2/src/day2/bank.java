/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day2;

/**
 *
 * @author arpandua
 */
public class bank {
 
    int Bankid = 101;
    String bankname = "TD";
    
    void getbankname()
    {
        System.out.println("Bank Name is " +bankname);
        
    }
    void setbankname(String name)
    {
        bankname = name;
        
    }
    
    
    
    
    
}


