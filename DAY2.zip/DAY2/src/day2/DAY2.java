/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day2;
import java.util.Scanner;
/**
 *
 * @author arpandua
 */
public class DAY2 {

   

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        bank mybank = new bank();
        
        System.out.println("bankid is " + mybank.Bankid);
        System.out.println("bank name is "+ mybank.bankname);
        
        bank yourbank = new bank();
        
        mybank.Bankid = 102;
        mybank.bankname = "Scotia Bank";
        
        System.out.println("bankid is " + mybank.Bankid);
        System.out.println("bank name is "+ mybank.bankname);
        
        
        mybank.Bankid = 1012;
        mybank.bankname = "Scotia Bank";
        
        System.out.println("bankid is " + mybank.Bankid);
        System.out.println("bank name is "+ mybank.bankname);
    
    
    
    mybank.getbankname();
    
    yourbank.setbankname("ICICI");
    yourbank.getbankname();
    
    Scanner myinput = new Scanner(System.in);
    
    String name;
    
    System.out.println("enter bank name");
    name = myinput.nextLine();
    
    yourbank.setbankname("name");
    
    
    ///////// arithmetic class///////
    
    
    
    arithmetic obj = new arithmetic();
    
    System.out.println("add of two no. is " +obj.add(5.23f,9.08f));
    
    arithmetic obj1 = new arithmetic();
    
    
    
    System.out.println("add of three no. is " +obj1.add(5,9,7));
    
    
    
    
     
    System.out.println("mul of no. is" +obj.mul(5,7,9));
    
    
    arithmetic.n1 = 20;
System.out.println(arithmetic.n1 + "" + arithmetic.n2);

    
person objp = new person();

objp.readdata();
objp.display();

emp e1 = new emp();
e1.displayemp();
e1.read();










    }
    
}
