/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day2;

import java.util.Scanner;

/**
 *
 * @author arpandua
 */
public class person {
    
    String firstname;
    String lastname;
    int age;
    
    
  void readdata()
  {
      Scanner input = new Scanner(System.in);
      
      System.out.println("enter first name");
      this.firstname = input.nextLine();
      
      System.out.println("enter last name");
      this.lastname = input.nextLine();
   
      System.out.println("enter age : ");
      this.age = input.nextInt();
  }
    
    
    
    
    void display()
    {
        System.out.println("enter last name" +this.firstname);
        System.out.println("enter last name" +this.lastname);
        System.out.println("enter Age" +this.age);
        
    }
    
    person()
    {
        this.firstname = "UNKNOWN";
        this.lastname = "UNKNOWN";
        this.age = 1;
        
    }
    
}
