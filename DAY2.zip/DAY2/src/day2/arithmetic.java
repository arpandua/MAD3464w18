/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day2;

/**
 *
 * @author arpandua
 */
public class arithmetic {
     
    static int n1;
final static int n2=7;
    




int add(int num1, int num2)
{
    
return num1 + num2;
 
}




int add(int num1, int num2, int num3)
{
    return num1 + num2 + num3;
}




float add(float num1, float num2)
{
    
return num1 + num2;
  
}





int add(int... num)
{
     int i = 0, sum = 0;
     for (i=0;i<num.length;i++)
     {
         sum+=num[i];
     }
return sum;
}






static int mul(int... num)
{
    int i = 0,ans = 1;
    for(i=0 ; i<num.length ; i++)
    {
        ans *= num[i];
    }
    
    System.out.println("multiplication : " +ans);
 
return ans;
}










}
