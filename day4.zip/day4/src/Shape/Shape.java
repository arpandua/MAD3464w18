/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Shape;

/**
 *
 * @author arpandua
 */
public class Shape {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       
         // can't create object for an abstract class      ///myshape obj = new myshape() {};
    circle abc= new circle();
    abc.draw();
    abc.display("it's a circle");
    
    
    
    }
}
    
    abstract class myshape
    {
        int x;
        int y;
        
       abstract void draw();
       
       void display(String msg)
       {
           System.out.println(msg);
           
       }
    }
    
    
class circle extends myshape
{

    @Override
    void draw() {
   
    System.out.println(" draw circle");
    
    super.x = 20;
    super.y = 10;
    
    
System.out.println("x =" +super.x);
System.out.println("y =" +super.y);
    
    
    }
    

}

abstract class rectangle extends myshape
{
int h;
abstract void draw();
}
