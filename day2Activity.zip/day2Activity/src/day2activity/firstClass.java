/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day2activity;
import java.util.Scanner;
/**
 *
 * @author arpandua
 */
class booking {
    
    
    
    public void booking()
   {
        System.out.println("press 1 for first class or press 2 for economy class ");
                Scanner choose = new Scanner(System.in);
                int select = choose.nextInt();
   if(select == 1)
   {
       economyclass();
   }
   else
   {
   firstclass();
   }
   }
    
    
  public void economyclass()
   {
        int ecoseatno = 0;
   
    if(ecoseatno<5)
    {
        for(int i = 0 ; i < economyclass.length ; i++)
        {
            boolean[] economyclass = null;
            if(!economyclass[i])
            {
                economyclass[i] = true;
                System.out.println("seat number: "+(i+1)); 
                ecoseatno++;
                break;
            }
        
        
        else 
            {
            System.out.println("no more tickets... the next flight leaves in 3 hours ");
    }        
        } 
    }
   }
            
              
  public void firstclass()
   {
        int firstseatno = 0;
   
    if(firstseatno<5)
    {
        for(int i = 0 ; i < economyclass.length ; i++)
        {
            boolean[] economyclass = null;
            boolean[] firstclass = null;
            if(!firstclass[i]){
                firstclass[i] = true;
                System.out.println("seat number: "+(i+1)); 
                firstseatno++;
                break;
            }
            
            
        
        }
    }}} 
   

   

