/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.sql.*;
/**
 *
 * @author arpandua
 */
public class javadatabase {
    
    static Connection conn;
    static PreparedStatement stmt;
    static ResultSet rs = null;
    static String User = "root";
    static String PASS = "";
    
    
    
    public static void main(String [] args)
    {
        connection();
        selecting();
    }
   
    static void connection()
            
    {
     
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("mysql//localhost/database",User,PASS);
        
        }
        
        catch(Exception e)
        {
            e.printStackTrace();
        }
         
        
        
        
    }
    
    static void inserting()
    {
        
        
    }
    
    static void selecting()
    {
        try
        {
            stmt = conn.prepareStatement("select * from data");
            
            //rs = stmt.execute();
            rs = stmt.executeQuery();
        
            while(rs.next())
            {
                System.out.println("id :" +rs.getInt(1) + "firstname : " +rs.getString(2) + "lastnname : " + rs.getString(3));
            
            
            }
        
        
        
        
        }
        
        catch(SQLException e)
            
                {
                    e.printStackTrace();
                }
        
        
        
    }
    
    static void delete()
    {
        
        
    }
    
    
    static void update()
    {
        
    }
    
    
    
}
